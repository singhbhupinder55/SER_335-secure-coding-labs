package org.jfm.event;

/**Interface implemented by any listener*/
public interface BroadcastListener
{

}
