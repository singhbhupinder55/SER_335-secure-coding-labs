/**
 * 
 */
package org.jfm.main;

/**
 * @author Nikhil's PC
 *
 */
public class Salt {
	String name;
	String salt;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}
}
